# --- flask/app.py ---
import os
import json
import threading
import datetime
from dateutil.tz import tzutc
from flask import Flask, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
import paho.mqtt.client as mqtt
from supabase import create_client, Client
from functools import wraps
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# --- Flask App ---
app = Flask(__name__)

# --- Supabase Setup ---
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")  # use anon/public key

if not SUPABASE_URL or not SUPABASE_KEY:
    raise RuntimeError("Missing SUPABASE_URL or SUPABASE_KEY in env")

try:
    supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
    print("✅ Supabase client created successfully")
except Exception as e:
    raise RuntimeError(f"Supabase client creation failed: {e}")

# --- JWT Auth ---
JWT_SECRET = os.getenv("JWT_SECRET", "dev_only")
TOKEN_TTL_MINUTES = int(os.getenv("TOKEN_TTL_MINUTES", "120"))

# --- MQTT Setup ---
MQTT_BROKER = os.getenv("BROKER")
MQTT_PORT = int(os.getenv("PORT", 8883))
MQTT_USER = os.getenv("MQTT_USER")
MQTT_PASSWORD = os.getenv("MQTT_PASS")  # fix env var name

TOPIC_IR = os.getenv("TOPIC_IR", "smart_safe/ir")
TOPIC_LDR = os.getenv("TOPIC_LDR", "smart_safe/ldr")
TOPIC_LED = os.getenv("TOPIC_LED", "smart_safe/led")
TOPIC_DOOR_CMD = os.getenv("TOPIC_SERVO_CMD", "servo/cmd")
TOPIC_DOOR_STATUS = os.getenv("TOPIC_SERVO_STATUS", "servo/status")

# MQTT Client
mqtt_client = mqtt.Client()

# Latest states
latest_ir = None
latest_ldr = None
door_state = "CLOSED"

def on_connect(client, userdata, flags, rc):
    print("✅ MQTT connected with result code:", rc)
    client.subscribe([(TOPIC_IR, 0), (TOPIC_LDR, 0), (TOPIC_DOOR_STATUS, 0)])
    print(f"Subscribed to: {TOPIC_IR}, {TOPIC_LDR}, {TOPIC_DOOR_STATUS}")

def on_message(client, userdata, msg):
    global latest_ir, latest_ldr, door_state
    try:
        payload = msg.payload.decode()
        if msg.topic == TOPIC_IR:
            latest_ir = int(payload)
        elif msg.topic == TOPIC_LDR:
            latest_ldr = int(payload)
        elif msg.topic == TOPIC_DOOR_STATUS:
            door_state = payload.upper()
        print(f"MQTT message -> {msg.topic}: {payload}")
    except Exception as e:
        print(f"MQTT parse error ({msg.topic}): {e}")

def start_mqtt():
    try:
        mqtt_client.username_pw_set(MQTT_USER, MQTT_PASSWORD)
        mqtt_client.tls_set()  # enable SSL/TLS
        mqtt_client.on_connect = on_connect
        mqtt_client.on_message = on_message
        mqtt_client.connect(MQTT_BROKER, MQTT_PORT, 60)
        mqtt_client.loop_forever()
    except Exception as e:
        print("⚠️ MQTT connection failed:", e)

threading.Thread(target=start_mqtt, daemon=True).start()

# --- Auth Helpers ---
def _role_for_username(user_name: str) -> str:
    return "root" if user_name == "root" else "sub"

def issue_token(user_name: str):
    payload = {
        "sub": user_name,
        "role": _role_for_username(user_name),
        "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=TOKEN_TTL_MINUTES)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")

def auth_required(role: str | None = None):
    def wrapper(fn):
        @wraps(fn)
        def inner(*args, **kwargs):
            hdr = request.headers.get("Authorization", "")
            if not hdr.startswith("Bearer "):
                return jsonify({"error":"missing bearer token"}), 401
            token = hdr.split(" ",1)[1]
            try:
                claims = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
            except Exception:
                return jsonify({"error":"invalid/expired token"}), 401
            if role and claims.get("role") != role:
                return jsonify({"error":"forbidden"}), 403
            request.user_claims = claims
            return fn(*args, **kwargs)
        return inner
    return wrapper

# --- Supabase Helpers ---
def get_user_by_name(user_name: str):
    res = supabase.table("users").select("*").eq("user_name", user_name).limit(1).execute()
    return res.data[0] if res.data else None

def create_user(user_name: str, password: str):
    return supabase.table("users").insert({
        "user_name": user_name,
        "user_pass": generate_password_hash(password)
    }).execute()

def get_safe_by_name(safe_name: str):
    res = supabase.table("safes").select("*").eq("safe_name", safe_name).limit(1).execute()
    return res.data[0] if res.data else None

def ensure_default_safe():
    root = get_user_by_name("root")
    if not root:
        create_user("root", "root123")
        root = get_user_by_name("root")
    res = supabase.table("safes").select("*").limit(1).execute()
    if not res.data:
        supabase.table("safes").insert({
            "safe_name": "main_safe",
            "created_by": root["user_id"]
        }).execute()
        return get_safe_by_name("main_safe")
    return res.data[0]

def user_has_access(user_name: str, safe_name: str) -> bool:
    safe = get_safe_by_name(safe_name)
    if not safe: return False
    user = get_user_by_name(user_name)
    if not user: return False
    if safe.get("created_by") == user["user_id"]: return True
    res = (supabase.table("adding_to_safe")
           .select("*")
           .eq("safe_name", safe_name)
           .eq("new_user", user_name)
           .execute())
    return bool(res.data)

# --- Routes ---
@app.route("/")
def home():
    s = ensure_default_safe()
    return jsonify({"status": "Smart Safe API 🚀", "safe_name": s["safe_name"], "door_state": door_state})

@app.route("/bootstrap/root", methods=["POST"])
def bootstrap_root():
    data = request.get_json(force=True)
    username = data.get("username","root")
    password = data.get("password","root123")
    if get_user_by_name(username):
        ensure_default_safe()
        return jsonify({"status":"exists","username":username})
    create_user(username, password)
    ensure_default_safe()
    return jsonify({"status":"created","username":username})

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json(force=True)
    username = data.get("username"); password = data.get("password")
    user = get_user_by_name(username)
    if not user or not check_password_hash(user["user_pass"], password):
        return jsonify({"error":"invalid credentials"}), 401
    token = issue_token(username)
    return jsonify({"token": token, "role": _role_for_username(username)})

@app.route("/safes/open", methods=["POST"])
@auth_required()
def safe_open():
    safe_name = (request.get_json(silent=True) or {}).get("safe_name", "main_safe")
    if not user_has_access(request.user_claims["sub"], safe_name):
        return jsonify({"error":"no access"}), 403
    mqtt_client.publish(TOPIC_DOOR_CMD, "OPEN")
    return jsonify({"status":"OPEN","safe": safe_name})

@app.route("/safes/close", methods=["POST"])
@auth_required()
def safe_close():
    safe_name = (request.get_json(silent=True) or {}).get("safe_name", "main_safe")
    if not user_has_access(request.user_claims["sub"], safe_name):
        return jsonify({"error":"no access"}), 403
    mqtt_client.publish(TOPIC_DOOR_CMD, "CLOSE")
    return jsonify({"status":"CLOSED","safe": safe_name})

# --- Run Flask ---
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
