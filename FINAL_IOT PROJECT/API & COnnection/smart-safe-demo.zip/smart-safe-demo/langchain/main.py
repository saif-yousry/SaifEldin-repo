# --- langchain/main.py ---
import os, json
from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
import paho.mqtt.client as mqtt

from langchain.agents import initialize_agent, AgentType, Tool
from langchain_google_genai import ChatGoogleGenerativeAI

load_dotenv()  # Load environment variables

# --- MQTT Setup ---
BROKER = os.getenv("BROKER", "broker.hivemq.com")
PORT = int(os.getenv("PORT", "8883"))
MQTT_USER = os.getenv("MQTT_USER")
MQTT_PASSWORD = os.getenv("MQTT_PASSWORD")

TOPIC_IR = os.getenv("TOPIC_IR", "smart_safe/ir")
TOPIC_LDR = os.getenv("TOPIC_LDR", "smart_safe/ldr")
TOPIC_LED = os.getenv("TOPIC_LED", "smart_safe/led")
TOPIC_SERVO_CMD = "servo/cmd"        # command topic
TOPIC_SERVO_STATUS = "servo/status"  # state topic

mqtt_client = mqtt.Client()

# --- Latest States ---
latest_ir = None
latest_ldr = None
door_state = "closed"
light_state = "unknown"
led_state = "off"

# --- MQTT Handlers ---
def on_connect(client, userdata, flags, rc):
    print("✅ MQTT Connected:", rc)
    client.subscribe([
        (TOPIC_IR, 0),
        (TOPIC_LDR, 0),
        (TOPIC_SERVO_STATUS, 0)
    ])
    print(f"Subscribed to: {TOPIC_IR}, {TOPIC_LDR}, {TOPIC_SERVO_STATUS}")

def on_disconnect(client, userdata, rc):
    print("⚠️ MQTT disconnected. Attempting reconnect...")
    try:
        client.reconnect()
    except Exception as e:
        print("❌ MQTT reconnect failed:", e)

def on_message(client, userdata, msg):
    global latest_ir, latest_ldr, door_state, light_state
    try:
        payload = msg.payload.decode()
        if msg.topic == TOPIC_IR:
            latest_ir = int(payload)
            door_state = "open" if latest_ir == 1 else "closed"
        elif msg.topic == TOPIC_LDR:
            latest_ldr = int(payload)
            light_state = "dark" if latest_ldr < 300 else "bright"
        elif msg.topic == TOPIC_SERVO_STATUS:
            door_state = payload.lower()
        print(f"MQTT message -> {msg.topic}: {payload}")
    except Exception as e:
        print(f"⚠️ MQTT parsing error ({msg.topic}): {e}")

# --- Connect MQTT ---
mqtt_client.username_pw_set(MQTT_USER, MQTT_PASSWORD)
mqtt_client.tls_set()
mqtt_client.on_connect = on_connect
mqtt_client.on_message = on_message
mqtt_client.on_disconnect = on_disconnect

try:
    mqtt_client.connect(BROKER, PORT, 60)
    mqtt_client.loop_start()
except Exception as e:
    print("❌ MQTT connection failed:", e)

# --- Tool Functions ---
def get_door_state(_=None):
    return f"Door is {door_state}" if latest_ir is not None else "IR reading not available"

def get_light_state(_=None):
    return f"Light is {light_state} (value={latest_ldr})" if latest_ldr is not None else "LDR reading not available"

def turn_led_on(_=None):
    global led_state
    if led_state == "on":
        return "LED already on"
    mqtt_client.publish(TOPIC_LED, "on")
    led_state = "on"
    return "LED turned on"

def turn_led_off(_=None):
    global led_state
    if led_state == "off":
        return "LED already off"
    mqtt_client.publish(TOPIC_LED, "off")
    led_state = "off"
    return "LED turned off"

def open_door(_=None):
    mqtt_client.publish(TOPIC_SERVO_CMD, "open")
    return "Door open command sent"

def close_door(_=None):
    mqtt_client.publish(TOPIC_SERVO_CMD, "close")
    return "Door close command sent"

# --- LangChain Agent ---
tools = [
    Tool(name="Get Door State", func=get_door_state, description="Get door state."),
    Tool(name="Get Light State", func=get_light_state, description="Get light state."),
    Tool(name="Turn LED On", func=turn_led_on, description="Turn LED on."),
    Tool(name="Turn LED Off", func=turn_led_off, description="Turn LED off."),
    Tool(name="Open Door", func=open_door, description="Open the door."),
    Tool(name="Close Door", func=close_door, description="Close the door."),
]

system_prompt = """
You are a smart safe IoT assistant.
Use only the provided tools to answer.
If sensor data is missing, report 'not available'.
"""

llm = ChatGoogleGenerativeAI(
    model="gemini-pro",
    google_api_key=os.getenv("GOOGLE_API_KEY")
)

agent = initialize_agent(
    tools=tools,
    llm=llm,
    agent=AgentType.STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True,
    handle_parsing_errors=True,
    return_only_outputs=True
)

# --- FastAPI ---
app = FastAPI()

@app.get("/status")
async def status():
    return {
        "door_state": door_state,
        "light_state": light_state,
        "led_state": led_state,
        "ir_raw": latest_ir,
        "ldr_raw": latest_ldr
    }

@app.post("/chat")
async def chat(request: Request):
    data = await request.json()
    user_input = data.get("text", "")
    try:
        reply = agent.invoke({
            "input": user_input,
            "chat_history": [{"role":"system","content":system_prompt}]
        })
        return JSONResponse({"reply": reply.get("output","")})
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)
